+ function(doc, win) {
  var docEle = doc.documentElement;
  var resizeEvt = 'orientationchange' in win ? 'onrientationchange' : 'resize';
  var recale = function() {
    var deviceWidth = docEle.getBoundingClientRect().width;
    docEle.style.fontSize = deviceWidth / 375 * 20 + 'px';
  };
  win.addEventListener(resizeEvt, recale, false);
  doc.addEventListener('DOMContentLoaded', recale, false);
}(document, window)
//这是一个很完美的刷新fontSize
axios部分
const getData = (url) => {
  const CancelToken = axios.CancelToken
  const source = CancelToken.source();
  const fn = (param = {}) => {
    if (fn.isFetching) { // 当上一个接口还没响应完成时，直接取消
      source.cancel('Operation canceled by the user.')
    }
    fn.isFetching = true
    return axios.get(url, {
      ...param,
      cancelToken: source.token
    }).then((res) => {
      fn.isFetching = false
      return res
    }).catch(function (thrown) {
      fn.isFetching = false
      if (axios.isCancel(thrown)) {
       
      } else {
        // 处理错误
      }
    })
  }
  fn.isFetching = false
  return fn
}
//一个popup的插件
export default function(Vue) {
    let MyPopup = Vue.extend(Popup)
    Vue.prototype.$basicGridInfo_popup = function(data) {
        let instance = new MyPopup({data}).$mount()
        document.body.appendChild(instance.$el)
        Vue.nextTick(() => {
            instance.show = true
        })
    }
}
