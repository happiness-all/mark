<template>
  <div class="input input-check-wrapper">
    <input :placeholder="placeholder" readonly :value="learnRange_copy" ref="checkInput" style="width: 100%;" type="text" class="input"
      name="" :title="learnRange_copy" @blur="leaveTree" @click="openTree">
    <i class="arrow el-input__icon el-icon-arrow-up" :class="{'open': treeShow}"></i>
    <div  v-show="treeShow" class="el-select-dropdown" @mouseover="inPop=true" @mouseout="leavePop">
      <div class="check-wrap">
        <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
        <el-checkbox-group v-model="checkedArr" @change="handleCheckedArrChange">
          <el-checkbox v-for="(city,i) in options" :label="city[keyVal]" :key="i">{{city[label]}}</el-checkbox>
        </el-checkbox-group>
      </div>

      <div class="btn-wrap">
        <span class="tree-btn sub" @click="submitFunc">确认</span>
        <span class="tree-btn tree-default-btn" @click="cancelFunc">取消</span>
      </div>
    </div>
    
  </div>
</template>

<script>
  import { getRecursionVal } from '@/lib/util'

  export default {
    props: {
      placeholder: '',
      options: {
        type: Array,
        default: () => []
      },
      default: {
        type: Array,
        default: () => []
      },
      label: '',
      keyVal: ''
    },
    // directives: { Clickoutside },
    data() {
      return {
        inPop: false,
        treeShow: false,
        //
        checkAll: false,
        checkedArr: [],

        checkedTempArr: [], // 处理临时
        isIndeterminate: false,
        learnRange_copy: ''
      }
    },
    computed: {
      learnRange() {
        // 刚进来时，option还是空的，所以getChecked会拿到空
        return getRecursionVal(this.getChecked(), this.label)
      }
    },
    watch: {
      default: {
        handler(newVal) {
          if (newVal) {
            this.checkedArr = newVal.map(opt => opt[this.keyVal])
            this.isIndeterminate = this.checkedArr.length < this.options.length && this.checkedArr.length !== 0
            this.learnRange_copy = this.learnRange

          }
        },
        immediate: true
      }
    },
    created() {

    },
    mounted() {
      this.checkedArr = this.default.map(opt => opt[this.keyVal]);
      this.checkedTempArr = this.default.map(opt => opt[this.keyVal]);
      let arr = this.default.map(opt => opt['roleName'])
      this.learnRange_copy = arr.join('，')
      this.isIndeterminate = this.checkedArr.length < this.options.length && this.checkedArr.length !== 0
    },
    methods: {
      openTree() {
        this.treeShow = true
        if (this.checkedArr.length === this.options.length) {
          this.checkAll = true
        }
      },
      leavePop() {
        this.$refs.checkInput.focus()
        this.inPop = false
      },
      leaveTree() {
        if (!this.inPop) {
          this.cancelFunc()
        }
      },
      submitFunc() {
        this.learnRange_copy = this.learnRange
        this.checkedTempArr = this.checkedArr
        this.treeShow = false
        this.$emit('getSearchSingle', this.checkedTempArr)
        this.$emit('submitFunc', this.checkedTempArr)
      },

      // 取消
      cancelFunc() {
        this.checkAll = false
        this.treeShow = false
        this.checkedArr = this.checkedTempArr
      },
      getChecked() {
        let arr = [];
        this.checkedArr.forEach(code => {
          let item = this.options.find(opt => opt[this.keyVal] == code)
          if (item) {
            arr.push(item)
          }
        })
        return arr;
      },
      handleClickOutside() {
        this.treeShow = false;
      },
      handleCheckAllChange(val) {
        this.checkedArr = val ? this.options.map(opt => opt[this.keyVal]) : [];
        this.isIndeterminate = false;

      },
      handleCheckedArrChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.options.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.options.length;

      }
    }
  }
</script>

<style scoped lang="less" rel="stylesheet/less">
  @import "../../assets/const.less";

  .input-check-wrapper.input {
    position: relative;
    .el-checkbox-group {
      display: flex;
      flex-direction: column;
      .el-checkbox {
        margin-left: 0 !important;
      }
    }
    .input {
      cursor: pointer;
      padding: 0 30px 0 15px;
    }
    .arrow {
      position: absolute;
      top: 50%;
      right: 4px;
      transform: translateY(-50%) rotateZ(180deg);
      transition: all 0.3s;
      height: 14px;
      line-height: 14px;
      color: #C0C4CC;
    }
    .arrow.open {
      transform: translateY(-50%) rotateZ(0deg);
    }
    .el-select-dropdown {
      width: 100%;
      border-radius: 2px; // padding: 10px;
     
      max-height: 300px; // overflow-y: auto;
      .el-checkbox {
        margin-bottom: 5px;
      }
    }
  }

  .tree-default-btn,
  .tree-btn {
    background: #fff;
    border-radius: 2px;
    padding: 0;
    height: 20px;
    line-height: 20px;
    color: #00aaff;
    text-align: center;
    float: right;
    margin-left: 15px;
    border: none;
    box-sizing: border-box;
    cursor: pointer;
  }

  .tree-default-btn {
    background: #fff;
    color: #999999;
  }

  .check-wrap {
    padding: 10px 0 10px 10px;
    max-height: 200px;
    overflow-y: scroll;
  }

  .btn-wrap {
    padding-top: 10px;
    padding-bottom:10px;
    border-top: 1px solid #ddd;
    height: 20px;
    text-align: right;
    .sub{
       margin-right: 20px
    }
    
  }
</style>
