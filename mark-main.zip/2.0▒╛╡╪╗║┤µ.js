import store from '@/store'

function _getCacheKey (key) {
  if (!store.state.appInfo.appCode) {
    console.error('appCode不存在---------------', key)
  }
  return `${store.state.appInfo.appCode}-${process.env.VUE_APP_VERSION_SERIAL}-${key}`
}

function _getStorage (strong) {
  return strong ? window.localStorage : window.sessionStorage
}

// 检查是否过期
function _checkExpire (samp, expire) {
  return samp > (Date.now() - expire * 24 * 60 * 60 * 1000)
}

/**
 * 初始化时清除缓存
 */
export function resetCache () {
  console.log('清除旧版本的缓存')
  let matchApp = new RegExp(store.state.appInfo.appCode)
  let matchKey = new RegExp(_getCacheKey(''))
  Object.keys(localStorage).forEach(key => {
    if (matchApp.test(key) && !matchKey.test(key)) {
      console.log('remove cache:', key)
      localStorage.removeItem(key)
    } else {
      // 清除百度地图缓存
      const bMapCache = new RegExp('BMap_')
      if (bMapCache.test(key)) {
        console.log('remove bmap cache:', key)
        localStorage.removeItem(key)
      }
    }
  })
}

/**
 * 清空缓存
 * @param {*} key 
 * @param {*} isStrong local or session
 */
export function removeCache (key, isStrong) {
  let storage = _getStorage(isStrong)
  const cacheKey = _getCacheKey(key)
  storage.removeItem(cacheKey)
}

/**
 * 写入缓存
 * @param {*} key 
 * @param {*} value 
 * @param {*} isStrong boolean
 */
export function setCache (key, value, isStrong) {
  let tempKey = key
  let symbol = ''
  if (key instanceof Array) {
    tempKey = key[0]
    symbol = key[1]
  }
  let storage = _getStorage(isStrong)
  const cacheKey = _getCacheKey(tempKey)
  let cache = {
    data: value,
    samp: Date.now()
  }
  if (symbol) {
    cache.symbol = symbol
  }
  storage.setItem(cacheKey, JSON.stringify(cache))
}

/**
 * 
 * @param {*} key 
 * @param {*} isStrong boolean
 * @param {*} expire 单位-小时
 * @returns 
 */
export function getCache (key, isStrong, expire) {
  let res = null
  let tempKey = key
  let symbol = ''
  if (key instanceof Array) {
    tempKey = key[0]
    symbol = key[1]
  }
  let storage = _getStorage(isStrong)
  const cacheKey = _getCacheKey(tempKey)
  try {
    let cache = JSON.parse(storage.getItem(cacheKey))
    if (cache) {
      if (expire !== undefined) {
        if (_checkExpire(cache.samp, expire)) {
          if (symbol) {
            if (cache.symbol === symbol) {
              res = cache.data
            } else {
              console.log('symbol不一致，清理', cacheKey)
              storage.removeItem(cacheKey)
            }
          } else {
            res = cache.data
          }
        } else {
          console.log('缓存已超时,清理', cacheKey)
          storage.removeItem(cacheKey)
        }
      } else {
        if (symbol) {
          if (cache.symbol === symbol) {
            res = cache.data
          } else {
            console.log('symbol不一致，清理', cacheKey)
            storage.removeItem(cacheKey)
          }
        } else {
          res = cache.data
        }
      }
    }
  } catch (e) {
    console.error('读取缓存出错,移除缓存:', e)
    storage.removeItem(cacheKey)
  }
  return res
}
