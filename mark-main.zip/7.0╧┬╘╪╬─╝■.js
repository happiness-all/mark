非特殊字符问题的正则表达式
export const nameChartReg = /^[-A-Za-z0-9_\u4e00-\u9fa5]*$/
其他下载文件的方法
let fileDownload = require("js-file-download");
 if (res.data.type == 'application/json') {
    var reader = new FileReader();
    reader.readAsText(res.data, 'utf-8')
    reader.onload = function (e) {
      window._xvueElementUI.Message({
        type: 'error',
        message: JSON.parse(reader.result).returnMessage,
      })
    }
  } else {
  //真正的下载文件的代码
    let content = res.headers['content-disposition']
    let fileName = content.split(";")[1]
    fileName = Base64.decode(fileName.substr(10, fileName.length))
    return fileDownload(res.data, fileName, '', undefined, onlyUrl)
  }
          
记得要修改请求中的一个属性
    // 下载所有文件
  downLoadAllFile(data) {
    return window._xvueAxios({
      method: 'post',
      url: BASE_URL+'/v1/grid/file/downLoadAllFile',
      data,
      responseType: 'blob'
    })
  }
  
  下载文件
  export const handleDownload = (res,fileName) => {
  const blob = res.data;
  、、、上传文件  除了用input 还可以用element -ui和 vant 中的  
  let reader = new FileReader()
  console.log(blob)
  reader.readAsDataURL(blob)
  if ('download' in document.createElement('a')) { //非ie下载
    reader.onload=(e)=>{
      let a = document.createElement('a')
    
      a.download = `${fileName}.zip`
      a.href = e.target.result
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
    }
  }else{
    navigator.msSaveOrOpenBlob(blob, `${fileName}.zip`);
  }
}
